//
// MessagePack for C++ static resolution routine
//
// Copyright (C) 2016 KONDO Takatoshi
//
//    Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//    http://www.boost.org/LICENSE_1_0.txt)
//

#ifndef MSGPACK_OBJECT_DECL_HPP
#define MSGPACK_OBJECT_DECL_HPP

#include "rpc/msgpack/v1/object_decl.hpp"
#include "rpc/msgpack/v2/object_decl.hpp"

#endif // MSGPACK_OBJECT_DECL_HPP
